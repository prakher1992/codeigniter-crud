<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Makecrud extends CI_Controller {
    public $data;

	function __construct()
    {
        parent::__construct();
        $this->load->library("Myrender");
        $check=$this->db->table_exists('input_detail');
        $this->load->dbforge();
        $this->data['tables']=$this->db->list_tables();
        if(!$check)
        {
        	$this->db->query("CREATE TABLE input_detail (id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,input_type VARCHAR(30)NOT NULL,class VARCHAR(30))");
    	}
    }
	public function index()
	{
        $this->myrender->load_view("createcrud_view",$this->data);
	}
	public function insert_fields()
	{
        $table_name=($this->input->post("table_name"));
        if ($this->db->table_exists($table_name) )
        {
            $this->session->set_flashdata('error',"This table already exists in your database");
            redirect(site_url('makecrud'));
        }
        else
        {
		      $count=count($this->input->post("input_type"));
		      $data=array('id' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'auto_increment' => TRUE
                ));
                $table_name=($this->input->post("table_name"));
                $count=count($this->input->post("input_type"));
                $data=array('id' => array(
                    'type' => 'INT',
                    'constraint' => 11,
                    'auto_increment' => TRUE
                ));
            for($i=0;$i<$count;$i++)
            {
                if($this->input->post("data_type")[$i]=="VARCHAR")
                {
                    $size=255;
                }
                else
                {
                    $size='';
                }
                $name=$this->input->post("name")[$i];
                //echo $name;die;
                $data[$name]=array('type'=>$this->input->post("data_type")[$i],
                                'constraint'=>$size
                    );
            }
                $this->dbforge->add_field($data);
                // print_r($data);die;
                $this->dbforge->add_key('id', TRUE);
                $this->dbforge->create_table($table_name);  
                //Create form View
                $create_formview=$this->create_formview($table_name);
                //Create Controller---------------------------------------------------
                $controller=$this->create_controller($table_name);
                //Create Listview
                $create_listview=$this->create_listview($table_name);
                //---------------
                $this->session->set_flashdata('success',"Crud Successfully Created");
                redirect(site_url('makecrud'));
	       }
       }
    public function create_controller($table_name)
    {
        $controller_name=ucfirst($table_name);
        $controller=
        '<?php
            defined("BASEPATH") OR exit("No direct script access allowed");

            class '.$controller_name.'_admin extends CI_Controller 
            {
                public $data;
                function __construct()
                {
                    parent::__construct();
                    $this->load->library("Myrender");
                    $this->load->model("Base_model");
                    $this->data["tables"]=$this->db->list_tables();
                }
                public function index($id="")
                {
                    $this->data["records"]=$this->Base_model->select_table("'.$table_name.'",array());
                    $this->myrender->load_view("'.$table_name.'_listview",$this->data);
                   
                }
                public function form($id="")
                {
                    if($id=="")
                    {
                        $this->data["type_form"]="Add";
                        $this->data["action"]="admin/'.$table_name.'_admin/form_process";
                        $this->myrender->load_view("'.$table_name.'_view",$this->data);
                    }
                    else
                    {
                        $this->data["type_form"]="Edit";
                        $this->data["action"]="admin/'.$table_name.'_admin/form_process/".$id;
                        $this->data["record"]=$this->Base_model->select_table("'.$table_name.'",array(),array("id"=>$id));
                        if(!empty($this->data["record"]))
                        {
                            $this->myrender->load_view("'.$table_name.'_view",$this->data);
                        }
                        else
                        {
                             $this->session->set_flashdata("error","No record found");
                            redirect(site_url("admin/'.$table_name.'_admin/list_all"));
                        }
                    }
                }
                public function form_process($id="")
                {
                    $insert_data=$this->input->post();
                    if($id=="")
                    {
                        $insert=$this->Base_model->insert_table("'.$table_name.'",$insert_data);
                        if($insert)
                        {
                            $this->session->set_flashdata("success","Record added successfully");
                            redirect(site_url("admin/'.$table_name.'_admin"));
                        }
                        else
                        {
                            $this->session->set_flashdata("error","Some error occur");
                            redirect(site_url("admin/'.$table_name.'_admin/form"));
                        }
                    }
                    else
                    {
                        $update=$this->Base_model->update_table("'.$table_name.'",$insert_data,array("id"=>$id));
                        if($update)
                        {
                            $this->session->set_flashdata("success","Record update successfully");
                            redirect(site_url("admin/'.$table_name.'_admin"));
                        }
                        else
                        {
                            $this->session->set_flashdata("error","Some error occur");
                            redirect(site_url("admin/'.$table_name.'_admin/form"));
                        }
                    }
                }
                public function delete_record($id)
                {
                    $check_record=$this->Base_model->select_table("'.$table_name.'",array(),array("id"=>$id));
                    if(!empty($check_record))
                    {
                        $delete=$this->Base_model->delete_table("'.$table_name.'",array("id"=>$id));
                        if($delete)
                        {
                            $this->session->set_flashdata("success","Record deleted successfully");
                            redirect(site_url("admin/'.$table_name.'_admin"));
                        }
                        else
                        {
                            $this->session->set_flashdata("error","Some error occur");
                            redirect(site_url("admin/'.$table_name.'_admin"));
                        }
                    }
                    else
                    {
                        $this->session->set_flashdata("error","No record found");
                        redirect(site_url("admin/'.$table_name.'_admin/list_all"));
                    }
                }
            }';
        $type_path =  APPPATH .'controllers/admin/';
        $controllerupload = $type_path;
        $check=file_put_contents($controllerupload.$controller_name.'_admin.php',$controller);
        if($check)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public function create_listview($table_name)
    {
        $table_fields=$this->db->list_fields($table_name);
        $list_view=
        '<div id="content">
            <div id="content-header">
                <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">All '.$table_name.'</a> 
                </div>
                <h1>All '.$table_name.'</h1>
            </div>
            <div class="container-fluid">
                <hr>
                <div class="row-fluid">
                    <?php if($this->session->flashdata("success")) { ?>                                   
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
                            </button>    
                            <strong>Success!</strong><?php echo $this->session->flashdata("success"); ?>
                        </div>
                    <?php } ?>
                    <?php if($this->session->flashdata("error")) { ?>
                        <div class="alert alert-warning alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
                            </button>
                            <strong>Error!</strong><?php echo $this->session->flashdata("error"); ?>
                        </div>
                    <?php } ?>
                    <div class="span12">
                        <div class="widget-box">
                            <div class="widget-title"> 
                                <span class="icon">
                                    <i class="icon-th"></i>
                                </span>
                                <h5>'.$table_name.'</h5>
                                <span class="">
                                    <a href="<?= base_url(); ?>admin/'.$table_name.'_admin/form" class="btn btn-primary label label-info">Add '.$table_name.'</a>
                                </span>
                            </div>
                            <div class="widget-content nopadding">
                                <table class="table table-bordered data-table">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>';
                                            foreach($table_fields as $fields)
                                            {
                                                if($fields!="id")
                                                $list_view.='<th>'.ucfirst($fields).'</th>';   
                                            }

                            $list_view.=' <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i=1; 
                                            foreach($records as $list){ ?>
                                        <tr class="gradeX">
                                            <td><?= $i; ?></td>';
                                            foreach($table_fields as $fields)
                                            {
                                                if($fields!="id")
                                $list_view.='<td><?= $list->'.$fields.' ?></td>';
                                             }
                                $list_view.='<td><a href="<?= base_url() ?>admin/'.$table_name.'_admin/form/<?=  $list->id; ?>">Edit</a>|<a href="<?= base_url() ?>admin/'.$table_name.'_admin/delete_record/<?=  $list->id; ?>">Delete</a></td>
                                        </tr>
                                    <?php 
                                        $i++;
                                            } ?>
                                 </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>';
    $type_path =  APPPATH .'views/admin/';
    $viewupload = $type_path;
    $check=file_put_contents($viewupload.$table_name.'_listview.php',$list_view);
    if($check)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public function create_formview($table_name)
    {
        $table_fields=$this->db->list_fields($table_name);
        $viewString=
        '<div id="content"><div id="content-header">
            <div id="breadcrumb"> 
                <a href="index.html" title="Go to Home" class="tip-bottom">
                    <i class="icon-home"></i> 
                    Home
                </a>
                <a href="#" class="tip-bottom">'.$table_name.'</a> 
                <a href="#" class="current"><?= $type_form; ?> '.$table_name.'</a> 
            </div>
            <h1><?= $type_form; ?> '.$table_name.'</h1>
        </div>
        <div class="container-fluid"><hr>
            <div class="row-fluid">
                <div class="span12">
                    <div class="widget-box">
                        <div class="widget-title">
                            <h5><?= $type_form; ?> Question</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <?php if($this->session->flashdata("success")) 
                            { ?>
                                <div class="alert alert-success alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                     <strong>Success!</strong>
                                    <?php echo $this->session->flashdata("success"); ?>
                                </div>
                            <?php } ?>
                            <?php if($this->session->flashdata("error")) 
                            { ?>
                                <div class="alert alert-warning alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><strong>Error!</strong><?php echo $this->session->flashdata("error"); ?>
                                </div>
                            <?php } ?>
                            <form action="<?= base_url().$action ?>" method="post" class="form-horizontal">';
                            $viewString.='<div class="form-actions">';
                            foreach($table_fields as $fields)
                            {
                                if($fields!="id")
                                {
                                    $viewString.='<div class="control-group">';
                                    $viewString.='<label class="control-label">'.$fields.'</label>
                                        <div class="controls">';
                                    $viewString.='<input type="'.$fields.'" value="<?= isset($record[0]->'.$fields.') ? $record[0]->'.$fields.' : " " ?>" name="'.$fields.'">';
                                    $viewString.='</div>';
                                }
                            }

                            $viewString.='<button type="submit" class="btn btn-success">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>';
        $type_path =  APPPATH .'views/admin/';
        $viewupload = $type_path;
        $check=file_put_contents($viewupload.$table_name.'_view.php',$viewString);
        if($check)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
