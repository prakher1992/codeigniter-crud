<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li> <a href="<?= base_url(); ?>"><i class="icon icon-signal"></i> <span>Create Crud</span></a> </li>
    <?php foreach($tables as $tbl)
    {
     ?>
    <li> <a href="<?= base_url(); ?>admin/<?= $tbl; ?>_admin"><i class="icon icon-signal"></i> <span><?= ucfirst($tbl); ?></span></a> </li>
   <?php } ?> 
    <!--<li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important">3</span></a>
      <ul>
        <li><a href="form-common.html">Basic Form</a></li>
        <li><a href="form-validation.html">Form with Validation</a></li>
        <li><a href="form-wizard.html">Form with Wizard</a></li>
      </ul>
    </li>-->
  </ul>
</div>
<!--sidebar-menu-->