<!DOCTYPE html>
<html lang="en">
<head>
<title>How much Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/css/fullcalendar.css" />
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/css/matrix-style.css" />
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/css/matrix-media.css" />
<link href="<?= base_url(); ?>assets/admin/font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/css/jquery.gritter.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<script src="<?= base_url(); ?>assets/admin/js/jquery.min.js"></script> 
</head>
<body>

<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.html">How Much</a></h1>
</div>
<!--close-Header-part--> 


<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <span class="text">Welcome User</span><b class="caret"></b></a>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="login.html"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
    <li class=""><a title="" href="<?= base_url(); ?>admin/login/logout"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>
<!--close-top-Header-menu-->


