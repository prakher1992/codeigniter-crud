<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/css/select2.css" />
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Create crud</a> </div>
    <h1>Create crud</h1>
  </div>
  <div class="container-fluid">
   <form method="post" action="<?=base_url();?>makecrud/insert_fields">
    <div class="row-fluid">
    <div class="span12">
      <div class="widget-box">
        <div class="widget-title">
          <h5>Table Name</h5>
        </div>
        <div class="widget-content nopadding">
          <?php if($this->session->flashdata('success')) { ?>                                   
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>    
              <strong>Success!</strong><?php echo $this->session->flashdata('success'); ?>
            </div>
               <?php } ?>
                 <?php if($this->session->flashdata('error')) { ?>
            <div class="alert alert-warning alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <strong>Error!</strong><?php echo $this->session->flashdata('error'); ?>
            </div>
                <?php } ?>
            <div class="control-group">
              <label class="control-label">Table Name :</label>
              <div class="controls">
                <input type="text" class="span11" name="table_name" onkeyup="nospaces(this)" required="true" />
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
    <hr>
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-th"></i> </span>
            <h5>Table columns</h5>
             <button type="button" id="addmore" class="btn btn-success">Add More</button></div>
          <div class="widget-content ">
            <table class="table table-bordered table-striped with-check">
              <thead>
                <tr>
                  <th>Field Type</th>
                  <th>Name</th>
                  <th>Data Type</th>
                  <th>Remove</th>
                </tr>
              </thead>
              <tbody id="more_ele">
                <tr>
                    <td> 
                      <select name="input_type[]" required="true">               
                        <option value="text">Text</option>
                        <option value="email">Email</option>
                      </select>
                    </td>
                    <td><input type="text" name="name[]" required="true" onkeyup="nospaces(this)"></td>
                    <td>
                      <select class="column_type" name="data_type[]" required="true">
                          <option value="INT">INT</option>
                          <option value="VARCHAR">VARCHAR</option>
                          <option value="TEXT">TEXT</option>
                          <option value="DATE">DATE</option>
                          <optgroup label="Numeric">
                            <option value="TINYINT">TINYINT</option>
                            <option value="SMALLINT">SMALLINT</option>
                            <option value="MEDIUMINT">MEDIUMINT</option>
                          </optgroup> 
                      </select>
                    </td>
                    <td></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
     <input type="submit" value="Save">
    </form>
  </div>
</div>
 <script type="text/javascript">
  $(document).ready(function() {
    var max_fields      = 30; //maximum input boxes allowed
    var wrapper         = $("#more_ele"); //Fields wrapper
    var add_button      = $("#addmore"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append(' <tr><td> <select name="input_type[]" required="true"><option value="text">Text</option><option value="email">Email</option></select></td><td><input type="text" name="name[]" onkeyup="nospaces(this)" required="true"></td><td><select class="column_type" name="data_type[]" required="true"><option value="INT">INT</option><option value="VARCHAR">VARCHAR</option><option value="TEXT">TEXT</option><option value="DATE">DATE</option><optgroup label="Numeric"><option value="TINYINT">TINYINT</option><option value="SMALLINT">SMALLINT</option><option value="MEDIUMINT">MEDIUMINT</option></optgroup></select></td><td><a href="#" class="remove_field">Remove</a></td></tr>');
        }
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).closest("tr").remove(); x--;
    })
});
function nospaces(t){
  if(t.value.match(/\s/g)){
    t.value=t.value.replace(/\s/g,'');
  }
}
</script>