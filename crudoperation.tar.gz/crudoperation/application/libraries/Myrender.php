<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Rendering Library
 *
 * @version    	1.0.0
 * @author     Prakher  <prakher1992@gmail.com>
 */
class Myrender
{

    protected $CI;

	//Constructor
	 public function __construct()
        {
               $this->CI =& get_instance();
        }
        public function load_view($view="",$data=array())
        {
            $this->CI->load->view('admin/header',$data);
            $this->CI->load->view('admin/sidebar');
            $this->CI->load->view('admin/'.$view);
            $this->CI->load->view('admin/footer');
        }
}