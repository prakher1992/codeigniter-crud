<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Author : Bibudha
 * Description : This model is used for Database Operation
 */

class base_model extends CI_Model{
	function __construct(){
		parent::__construct();
	}
	
	//Global Update Function
	public function update_table($table_name,$data_array,$where_array,$type_of="and")
		{
		if($type_of == "and")
			{
			foreach($where_array as $key=>$val)
				{
				$this->db->where($key,$val);
				}
			}
		else if($type_of == "or")
			{
			$i=0;
			foreach($where_array as $key=>$val)
				{
				
				
				if($i >= 1)
					{
					$this->db->or_where($key,$val);
					}
					else
					{
					$this->db->where($key,$val);
					}
					
					$i++;
				}
			
			}
		
		if($this->db->update($table_name,$data_array))
			{
			
			return true;
			}
		else
			{
			return false;
			}
		}
		
	//Global Insert Function
	public function insert_table($table_name,$data_array,$return_type=0)
		{
		if($return_type == 1)
			{
			if($this->db->insert($table_name,$data_array))
				{
				return $this->db->insert_id();
				}
			else	
				{
				return 0;
				}
			}
		else
			{
			if($this->db->insert($table_name,$data_array))
				{
				return true;
				}
			else	
				{
				return false;
				}
			}
		}
		
	//Global Delete Function
	public function delete_table($table_name,$where_array,$type_of="and")
	{
		if($type_of == "and")
			{
			foreach($where_array as $key=>$val)
				{
				$this->db->where($key,$val);
				}
			}
		else if($type_of == "or")
			{
			$i=0;
			foreach($where_array as $key=>$val)
				{
				
				
				if($i >= 1)
					{
					$this->db->or_where($key,$val);
					}
					else
					{
					$this->db->where($key,$val);
					}
					
					$i++;
				}
			}
		
		if($this->db->delete($table_name))
			{
			return true;
			}
		else
			{
			return false;
			}
	}
	
	//Global Select Function
	public function select_table($table_name,$fetch_col,$where_array=array(),$orderby_array=array(),$groupby_array=array(),$type_of="and",$num=0,$limit_value=1000,$ofset_value=0)
	{
	$fetch_string = implode(",",$fetch_col);
	$this->db->select($fetch_string);
			if($type_of == "and")
			{
			foreach($where_array as $key=>$val)
				{
					if(strstr($key,"%%", true) === false)
						{
						$this->db->where($key,$val);
						}
						else
						{
						$this->db->or_like(strstr($key, '%%', true),$val);
						}
				}
			}
		else if($type_of == "or")
			{
			$i=0;
			foreach($where_array as $key=>$val)
				{
							
				if($i >= 1)
					{
					$this->db->or_where($key,$val);
					}
					else
					{
					$this->db->where($key,$val);
					}
					
					$i++;
				}
			}
		if(!empty($orderby_array))
			{
			foreach($orderby_array as $okey=>$oval)
				{
				$this->db->order_by($okey,$oval);
				}
			}
		if(!empty($groupby_array))
			{
			$group_string = implode(",",$groupby_array);
			$this->db->group_by($group_string);
			}			
			
		$this->db->from($table_name);
		$this->db->limit($limit_value,$ofset_value);
		$query=$this->db->get();
		if($num == 1)
			{
			return $query->num_rows();
			}
		else
			{
			
			//echo $this->db->last_query();
			return $query->result();
			
			}
	}
	
	/*
	
	$tabl1 --->table1
	$als1 --->Alias of first table1
	$table_array=array([0]=>array('name' => 'tbl2',
								   'als' => 't2',
								   'on'=>'t2.abc=t1.cdf'),
						[1]=>array('name' => 'tbl2',
								   'als' => 't2',
								   'on'=>'t2.abc=t1.cdf')		   
								   );
								   
	$fetch_col ---> as you send before but here you make the array with alias
    $where_array--->as you send before but here you make the array with alias	
	$orderby_array-->as you send before but here you make the array with alias	
	$groupby_array-->as you send before but here you make the array with alias	
	*/

	public function select_with_join($tabl1,$als1,$table_array,$fetch_col,$where_array,$orderby_array=array(),$groupby_array=array(),$type_of="and",$num=0,$limit_value=1000,$ofset_value=0)
	{

	$fetch_string = implode(",",$fetch_col);
	$this->db->select($fetch_string);
	$this->db->from($tabl1." ".$als1);
	foreach($table_array as $tbl)
		{
		if(!isset($tbl['type']))
		{
		$this->db->join($tbl['name']." ".$tbl['als'],$tbl['on']);
		}
		else
		{
		$this->db->join($tbl['name']." ".$tbl['als'],$tbl['on'],$tbl['type']);
		}
		}
	if($type_of == "and")
			{
			foreach($where_array as $key=>$val)
				{
				if(strstr($key,"%%", true) === false)
						{
						$this->db->where($key,$val);
						}
						else
						{
						$this->db->or_like(strstr($key, '%%', true),$val);
						}
				}
			}
		else if($type_of == "or")
			{
							$i=0;
			foreach($where_array as $key=>$val)
				{
							
				if($i >= 1)
					{
					if(strstr($key,"%%", true) === false)
						{
						$this->db->or_where($key,$val);
						}
					else
						{
						$this->db->or_like(strstr($key, '%%', true),$val);
						}
					}
					else
					{
					if(strstr($key,"%%", true) === false)
						{
						$this->db->where($key,$val);
						}
					else
						{
						$this->db->or_like(strstr($key, '%%', true),$val);
						}
					}
					
					$i++;
				}
			}
		
		if(!empty($orderby_array))
			{
			foreach($orderby_array as $okey=>$oval)
				{
				$this->db->order_by($okey,$oval);
				}
			}

			if(!empty($groupby_array))
			{
			$group_string = implode(",",$groupby_array);
			$this->db->group_by($group_string);
			
			}			
		$this->db->limit($limit_value,$ofset_value);
		$query=$this->db->get();
		//echo $this->db->last_query();
		if($num == 1)
			{
			return $query->num_rows();
			}
		else
			{
			return $query->result();
			}
		
	
	}
	
	//Direct Query
	public function direct_query($qry,$type="select")
	{
	$query=$this->db->query($qry);
		if($type=="update"){
		return true;
		}
		elseif($type=="select")
		{
		//echo $this->db->last_query();
		return $query->result();
		}
		
	}
	
}