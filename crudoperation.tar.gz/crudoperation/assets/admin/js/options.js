$("document").ready(function()
{
	$("#btn_login").click(function()
	{ 
	var valid_form=$("#newoptions").valid();
	/*if(valid_form!=false)
	{
		alert("valid");
	}
	else
	{
		alert("not valid");
	}*/
	$('#newoptions').validate({
		 rules: {  
			'option[]':{
		  		required: true,
			 },
			price:{
				required : true,
			},
			image:{
				required : true
			}  
		  }
		});
	});
});
