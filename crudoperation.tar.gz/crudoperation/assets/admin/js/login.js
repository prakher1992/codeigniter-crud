$("document").ready(function()
{
	$("#btn_login").click(function()
	{ 
		$("#error_div").hide();
		var con=$("#user_login").serialize();
		var valid_form=$("#user_login").valid();
		//alert(baseurl);
		var send_url=baseurl+"admin/login/login_process";
		if(valid_form!=false)
		{
		$.ajax(
		{
			type: "post",
			url: send_url,
			data:con,
			dataType:"json",
			success: function (data, status, jqXHR) 
			{			
				if(data['status'] == "success")
				{										
					window.location=baseurl+'admin/dashboard';								
				}
				else
				{			
					$("#error_div").html(" ");
					var disbutton='<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
					$("#error_div").append(disbutton+data['position']);
					$("#error_div").show();		
					$("#user_login")[0].reset();									
				}
			},
			error: function (jqXHR, status, errorThrown) 
			{            
				alert("error");
			}
		});}
	});
	$('#user_login').validate({
		 rules: {  
			user_name:{
		  		required: true,
			 },
			password:{
				required : true
			}  
		  }
		});
});